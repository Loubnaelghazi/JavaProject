package com.example.essalaf;

public class Commande {
    private int Id;
    private int Produits;
    private String Nom_client;
    private float Montant;

    public Commande(int id, int produits, String nom_client, float montant) {
        Id = id;
        Produits = produits;
        Nom_client = nom_client;
        Montant = montant;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public int getProduits() {
        return Produits;
    }

    public void setProduits(int produits) {
        Produits = produits;
    }

    public String getNom_client() {
        return Nom_client;
    }

    public void setNom_client(String nom_client) {
        Nom_client = nom_client;
    }

    public float getMontant() {
        return Montant;
    }

    public void setMontant(float montant) {
        Montant = montant;
    }
}